<?php
require_once __DIR__ . '/inc/bootstrap.php';
if(auth_user()) redirect_to('/');
$error='';
if(is_post()){
  $mat=trim(ps('matricula')); $sen=trim(ps('senha'));
  try{
    if(auth_login($mat,$sen)){ flash_set('success','Bem-vindo! Login realizado com sucesso.'); redirect_to('/'); }
    $error='Matrícula ou senha inválidas.';
  } catch(Throwable $e){ $error=$e->getMessage(); }
}
$cfg=app_cfg();
?><!doctype html><html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Entrar • <?= h($cfg['app_name']) ?></title>
<link rel="stylesheet" href="<?= h(url('/assets/vendor/bootstrap/css/bootstrap.min.css')) ?>">
<link rel="stylesheet" href="<?= h(url('/assets/css/app.css')) ?>">
</head><body class="login-wrap d-flex align-items-center">
<?php if($error): ?><script>window.__FLASH__ = <?= json_encode(['type'=>'danger','title'=>'Falha no login','message'=>$error], JSON_UNESCAPED_UNICODE) ?>;</script><?php endif; ?>
<div class="container py-5"><div class="row g-4 align-items-stretch">
  <div class="col-lg-7">
    <div class="login-glass h-100 p-4 p-lg-5">
      <div class="d-flex align-items-center gap-3 mb-4"><img src="<?= h($cfg['logo_url']) ?>" alt="Logo" height="40"><div><div class="fs-3 fw-bold"><?= h($cfg['app_name']) ?></div><div class="text-white-50">Plataforma corporativa de curadoria, governança e trilhas</div></div></div>
      <h1 class="display-5 fw-bold mb-3">Uma base completa para trocar planilhas por gestão profissional</h1>
      <p class="text-white-50 fs-5">Cadastre conteúdos, mantenha histórico de versões, registre múltiplos chamados por área, monte trilhas e utilize um copiloto local para acelerar o desenho das jornadas.</p>
      <div class="row g-3 mt-4">
        <div class="col-sm-6"><div class="p-3 rounded-4 bg-white bg-opacity-10 border border-white border-opacity-10 h-100"><div class="fw-semibold mb-1">Dashboard executivo</div><div class="small text-white-50">KPIs, gráficos de tema e tipo, uso em trilhas e carga horária total.</div></div></div>
        <div class="col-sm-6"><div class="p-3 rounded-4 bg-white bg-opacity-10 border border-white border-opacity-10 h-100"><div class="fw-semibold mb-1">Versionamento legível</div><div class="small text-white-50">Snapshot com os dados exatos de cada versão e motivo da mudança.</div></div></div>
        <div class="col-sm-6"><div class="p-3 rounded-4 bg-white bg-opacity-10 border border-white border-opacity-10 h-100"><div class="fw-semibold mb-1">Copiloto funcional</div><div class="small text-white-50">Experiência conversacional local para sugerir conteúdos da trilha.</div></div></div>
        <div class="col-sm-6"><div class="p-3 rounded-4 bg-white bg-opacity-10 border border-white border-opacity-10 h-100"><div class="fw-semibold mb-1">Admin forte</div><div class="small text-white-50">Parâmetros para temas, tags, status, públicos, categorias e motivos.</div></div></div>
      </div>
      <div class="small text-white-50 mt-4">Tema visual inspirado em shells administrativos do estilo Admindek, com assets locais.</div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="login-card h-100 p-4 p-lg-5">
      <div class="text-uppercase small text-secondary fw-semibold mb-1">Acesso interno</div>
      <h2 class="fw-bold mb-1">Entrar na plataforma</h2>
      <div class="text-secondary mb-4">Use a matrícula e a senha que estão na base de exemplo para testar.</div>
      <form method="post">
        <div class="mb-3"><label class="form-label fw-semibold">Matrícula</label><input class="form-control form-control-lg" name="matricula" required placeholder="Ex.: 1001" value="<?= h(ps('matricula')) ?>"></div>
        <div class="mb-3"><label class="form-label fw-semibold">Senha</label><input class="form-control form-control-lg" type="password" name="senha" required placeholder="••••••••"></div>
        <div class="d-grid mt-4"><button class="btn app-btn-primary btn-lg text-white fw-semibold">Entrar</button></div>
      </form>
      <hr class="my-4">
      <div class="small text-secondary"><div><strong>Login de teste:</strong></div><div>1001 / admin123</div><div>1002 / curador123</div><div>1003 / leitor123</div></div>
    </div>
  </div>
</div></div>
<div id="customModalRoot"></div>
<script src="<?= h(url('/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')) ?>"></script>
<script src="<?= h(url('/assets/js/app.js')) ?>"></script>
</body></html>
