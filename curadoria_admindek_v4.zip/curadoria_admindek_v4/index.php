<?php
require_once __DIR__ . '/inc/bootstrap.php';
$path=current_path();
if($path==='/'){ require __DIR__ . '/pages/dashboard.php'; exit; }
if($path==='/conteudos'){ require __DIR__ . '/pages/conteudos/list.php'; exit; }
if($path==='/conteudos/novo'){ require __DIR__ . '/pages/conteudos/' . (is_post() ? 'save.php' : 'form.php'); exit; }
if($path==='/conteudos/editar'){ require __DIR__ . '/pages/conteudos/' . (is_post() ? 'save.php' : 'form.php'); exit; }
if($path==='/conteudos/versoes'){ require __DIR__ . '/pages/conteudos/versions.php'; exit; }
if($path==='/conteudos/versao'){ require __DIR__ . '/pages/conteudos/version_view.php'; exit; }
if($path==='/trilhas'){ require __DIR__ . '/pages/trilhas/list.php'; exit; }
if($path==='/trilhas/builder'){ require __DIR__ . '/pages/trilhas/' . (is_post() ? 'save.php' : 'builder.php'); exit; }
if($path==='/logs'){ require __DIR__ . '/pages/logs/list.php'; exit; }
if($path==='/admin'){ require __DIR__ . '/pages/admin/index.php'; exit; }
if(str_starts_with($path,'/admin/')){ require __DIR__ . '/pages/admin/crud.php'; exit; }
if($path==='/api/auto-trilha'){ require __DIR__ . '/pages/api/auto_trilha.php'; exit; }
if($path==='/api/copilot'){ require __DIR__ . '/pages/api/copilot.php'; exit; }
http_response_code(404); layout_header('Página não encontrada','A rota solicitada não existe.'); ?><div class="app-panel p-5 text-center"><div class="display-6 fw-bold">404</div><div class="text-secondary mt-2">Essa página não existe ou a URL foi digitada incorretamente.</div><a class="btn app-btn-primary text-white mt-4 px-4" href="<?= h(url('/')) ?>">Voltar ao Dashboard</a></div><?php layout_footer(); ?>
