<?php
function app_cfg(){ static $cfg=null; if($cfg===null) $cfg=require __DIR__ . '/../config/app.php'; return $cfg; }
function base_url(){ return rtrim(app_cfg()['base_url'],'/'); }
function url($path=''){ return base_url().$path; }
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function is_post(){ return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }
function redirect_to($path){ header('Location: '.url($path)); exit; }
function current_path(){ $path=parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'; $base=base_url(); if(str_starts_with($path,$base)) $path=substr($path,strlen($base)); $path='/' . ltrim($path,'/'); return $path===''?'/':$path; }
function qs($k,$d=''){ return $_GET[$k] ?? $d; }
function ps($k,$d=''){ return $_POST[$k] ?? $d; }
function current_user_name(){ return $_SESSION['user']['nome'] ?? 'Convidado'; }
function array_pluck_int($rows,$key){ $out=[]; foreach($rows as $r) $out[]=(int)($r[strtolower($key)] ?? $r[$key] ?? 0); return $out; }
function hms_to_seconds($hms){ if(!$hms) return 0; $p=explode(':',$hms); if(count($p)!==3) return 0; return ((int)$p[0]*3600)+((int)$p[1]*60)+(int)$p[2]; }
function seconds_to_hms($seconds){ $seconds=max(0,(int)$seconds); $h=floor($seconds/3600); $m=floor(($seconds%3600)/60); $s=$seconds%60; return sprintf('%02d:%02d:%02d',$h,$m,$s); }
function selected_hms_total($items){ $sum=0; foreach($items as $i) $sum += hms_to_seconds($i['carga_horaria'] ?? '00:00:00'); return seconds_to_hms($sum); }
