<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
date_default_timezone_set((require __DIR__ . '/../config/app.php')['timezone']);
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/flash.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/repo.php';
require_once __DIR__ . '/ai.php';
require_once __DIR__ . '/layout.php';
