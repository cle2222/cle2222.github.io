<?php
function db_connect(){
  static $conn=null; if($conn) return $conn;
  $cfg=require __DIR__ . '/../config/db.php';
  $opt=''; foreach(($cfg['options'] ?? []) as $k=>$v) $opt .= $k.'='.$v.';';
  foreach($cfg['drivers'] as $driver){
    if(!empty($cfg['trusted_connection'])){
      $str="Driver=$driver;Server={$cfg['server']};Database={$cfg['database']};Trusted_Connection=yes;$opt";
      $try=@odbc_connect($str,'','');
    } else {
      $str="Driver=$driver;Server={$cfg['server']};Database={$cfg['database']};$opt";
      $try=@odbc_connect($str,$cfg['user'],$cfg['pass']);
    }
    if($try){ $conn=$try; return $conn; }
  }
  throw new Exception('Não foi possível conectar via ODBC. Revise config/db.php, o driver do Windows e as extensões ODBC do PHP.');
}
function db_stmt($sql,$params=[]){
  $c=db_connect(); $stmt=@odbc_prepare($c,$sql);
  if(!$stmt) throw new Exception('Falha ao preparar SQL: '.@odbc_errormsg($c));
  $ok=@odbc_execute($stmt,array_values($params));
  if(!$ok) throw new Exception('Falha ao executar SQL: '.@odbc_errormsg($c));
  return $stmt;
}
function db_all($sql,$params=[]){ $s=db_stmt($sql,$params); $rows=[]; while($r=odbc_fetch_array($s)) $rows[]=array_change_key_case($r,CASE_LOWER); return $rows; }
function db_one($sql,$params=[]){ $r=db_all($sql,$params); return $r[0] ?? null; }
function db_scalar($sql,$params=[],$field=null){ $r=db_one($sql,$params); if(!$r) return null; if($field!==null) return $r[strtolower($field)] ?? null; return reset($r); }
function db_exec($sql,$params=[]){ db_stmt($sql,$params); return true; }
