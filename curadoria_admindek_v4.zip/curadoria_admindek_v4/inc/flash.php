<?php
function flash_set($type,$message,$title=''){ $_SESSION['flash']=['type'=>$type,'message'=>$message,'title'=>$title]; }
function flash_get(){ if(empty($_SESSION['flash'])) return null; $m=$_SESSION['flash']; unset($_SESSION['flash']); return $m; }
