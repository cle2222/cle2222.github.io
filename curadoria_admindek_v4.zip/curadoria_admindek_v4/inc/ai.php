<?php
function ai_auto_trilha($temaId,$excludeIds=[]){
  $params=[$temaId,$temaId];
  $where="c.ativo = 1 AND c.tema_id = ?";
  if($excludeIds){
    $ph=implode(',', array_fill(0,count($excludeIds),'?'));
    $where.=" AND c.id NOT IN ($ph)";
    foreach($excludeIds as $id) $params[]=$id;
  }
  return db_all("SELECT TOP 12 c.id, c.titulo, c.carga_horaria, c.versao, t.nome AS tema, tp.nome AS tipo, ISNULL(freq.f,0) AS score_base, ISNULL(pop.uso_trilhas,0) AS uso_total FROM conteudos c INNER JOIN temas t ON t.id = c.tema_id INNER JOIN tipos_conteudo tp ON tp.id = c.tipo_id LEFT JOIN (SELECT tc.conteudo_id, COUNT(*) AS f FROM trilha_conteudos tc INNER JOIN trilhas tr ON tr.id = tc.trilha_id WHERE tr.tema_id = ? GROUP BY tc.conteudo_id) freq ON freq.conteudo_id = c.id LEFT JOIN (SELECT conteudo_id, COUNT(*) AS uso_trilhas FROM trilha_conteudos GROUP BY conteudo_id) pop ON pop.conteudo_id = c.id WHERE $where ORDER BY (ISNULL(freq.f,0) * 3 + ISNULL(pop.uso_trilhas,0)) DESC, c.criado_em DESC", $params);
}
function ai_copilot_reply($prompt,$temaId=0,$selectedIds=[]){
  $p=mb_strtolower(trim($prompt)); $message='Analisei o seu pedido e montei uma resposta inicial com base no tema, no histórico de uso e no conjunto já selecionado.';
  if(str_contains($p,'onboarding')) $message='Para onboarding, priorizei conteúdos introdutórios, visão geral do processo e conteúdos base para entrada na operação.';
  elseif(str_contains($p,'suporte') || str_contains($p,'técnico')) $message='Para suporte técnico, foquei em conteúdos de diagnóstico, passo a passo operacional e atendimento.';
  elseif(str_contains($p,'falta') || str_contains($p,'essencial')) $message='Comparei o conjunto atual com trilhas parecidas e destaquei lacunas prováveis.';
  elseif(str_contains($p,'comercial')) $message='Para o tema comercial, a recomendação prioriza fluxo de argumentação, processo e objeções.';
  elseif(str_contains($p,'rh')) $message='Para RH, a recomendação olha onboarding, processo, atualização e governança.';
  $items=$temaId>0 ? ai_auto_trilha($temaId,$selectedIds) : [];
  $reasons=['Mais reutilizado em trilhas parecidas','Aderente ao tema principal','Bom ponto de partida para o escopo','Complementa lacunas do conjunto atual'];
  $cards=[]; $i=0; foreach($items as $it){ $cards[]=['id'=>(int)$it['id'],'titulo'=>$it['titulo'],'tema'=>$it['tema'],'tipo'=>$it['tipo'],'versao'=>$it['versao'],'carga_horaria'=>$it['carga_horaria'],'reason'=>$reasons[$i % count($reasons)]]; $i++; }
  return ['message'=>$message,'items'=>$cards];
}
