<?php
function layout_header($title='',$subtitle=''){
  $cfg=app_cfg(); $path=current_path(); $flash=flash_get();
?><!doctype html><html lang="pt-br"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($title ? $title . ' • ' . $cfg['app_name'] : $cfg['app_name']) ?></title>
<link rel="stylesheet" href="<?= h(url('/assets/vendor/bootstrap/css/bootstrap.min.css')) ?>">
<link rel="stylesheet" href="<?= h(url('/assets/css/app.css')) ?>">
</head><body class="app-body">
<?php if($flash): ?><script>window.__FLASH__ = <?= json_encode($flash, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;</script><?php endif; ?>
<div class="app-shell">
  <aside class="app-sidebar">
    <div class="sidebar-brand"><img src="<?= h($cfg['logo_url']) ?>" alt="Logo" class="brand-logo"><div><div class="brand-title"><?= h($cfg['app_name']) ?></div><div class="brand-subtitle"><?= h($cfg['company_name']) ?> • Curadoria</div></div></div>
    <div class="sidebar-profile"><div class="small text-white-50 mb-1">Conectado como</div><div class="fw-semibold"><?= h(current_user_name()) ?></div><div class="small text-white-50"><?= h(auth_user()['perfil'] ?? '') ?></div></div>
    <nav class="sidebar-nav">
      <a class="sidebar-link <?= $path==='/'?'active':'' ?>" href="<?= h(url('/')) ?>">Dashboard</a>
      <a class="sidebar-link <?= str_starts_with($path,'/conteudos')?'active':'' ?>" href="<?= h(url('/conteudos')) ?>">Conteúdos</a>
      <a class="sidebar-link <?= str_starts_with($path,'/trilhas')?'active':'' ?>" href="<?= h(url('/trilhas')) ?>">Trilhas</a>
      <a class="sidebar-link <?= str_starts_with($path,'/logs')?'active':'' ?>" href="<?= h(url('/logs')) ?>">Logs</a>
      <?php if(auth_is_admin()): ?><a class="sidebar-link <?= str_starts_with($path,'/admin')?'active':'' ?>" href="<?= h(url('/admin')) ?>">Admin</a><?php endif; ?>
    </nav>
    <div class="sidebar-footer"><a class="btn btn-sm app-btn-outline w-100" href="<?= h(url('/logout')) ?>">Sair</a></div>
  </aside>
  <div class="app-main">
    <header class="topbar">
      <div><div class="topbar-title"><?= h($title ?: $cfg['app_name']) ?></div><?php if($subtitle): ?><div class="topbar-subtitle"><?= h($subtitle) ?></div><?php endif; ?></div>
      <div class="d-flex align-items-center gap-2 flex-wrap">
        <span class="topbar-badge">Admindek-inspired</span>
        <span class="topbar-badge">Bootstrap local</span>
        <span class="topbar-badge">ODBC SQL Server</span>
      </div>
    </header>
    <main class="app-content">
<?php }
function layout_footer(){ ?>
    </main>
  </div>
</div>
<div id="customModalRoot"></div>
<script src="<?= h(url('/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')) ?>"></script>
<script src="<?= h(url('/assets/js/app.js')) ?>"></script>
</body></html>
<?php } ?>
