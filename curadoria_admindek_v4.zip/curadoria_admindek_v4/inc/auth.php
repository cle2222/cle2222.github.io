<?php
function auth_user(){ return $_SESSION['user'] ?? null; }
function auth_require(){ if(!auth_user()) redirect_to('/login'); }
function auth_is_admin(){ return strtolower((string)($_SESSION['user']['perfil'] ?? '')) === 'admin'; }
function auth_login($matricula,$senha){
  $u=db_one("SELECT TOP 1 id, matricula, nome, perfil FROM colaboradores WHERE matricula = ? AND senha = ? AND ativo = 1", [$matricula,$senha]);
  if(!$u) return false;
  $_SESSION['user']=['id'=>(int)$u['id'],'matricula'=>$u['matricula'],'nome'=>$u['nome'],'perfil'=>$u['perfil']];
  return true;
}
function auth_logout(){ unset($_SESSION['user']); }
