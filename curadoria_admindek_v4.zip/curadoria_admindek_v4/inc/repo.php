<?php
function repo_all_active($table){ return db_all("SELECT id, nome, ativo FROM $table WHERE ativo = 1 ORDER BY nome"); }
function repo_all($table){ return db_all("SELECT id, nome, ativo FROM $table ORDER BY nome"); }
function repo_content_tags($contentId){ return array_pluck_int(db_all("SELECT tag_id FROM conteudo_tags WHERE conteudo_id = ?", [$contentId]), 'tag_id'); }
function repo_content_tickets($contentId){ return db_all("SELECT cc.id, cc.area_id, a.nome AS area_nome, cc.numero, cc.observacao FROM conteudo_chamados cc INNER JOIN areas_solicitantes a ON a.id = cc.area_id WHERE cc.conteudo_id = ? ORDER BY cc.id", [$contentId]); }
function repo_version_detail($versionId){ $r=db_one("SELECT v.id, v.conteudo_id, v.versao, v.motivo, v.dados_json, v.criado_em, c.nome AS usuario FROM conteudos_versoes v LEFT JOIN colaboradores c ON c.id = v.criado_por WHERE v.id = ?", [$versionId]); if(!$r) return null; $r['dados']=json_decode($r['dados_json'] ?? '{}', true); return $r; }
function repo_trilha_selected($trilhaId){ return db_all("SELECT tc.conteudo_id AS id, c.titulo, c.carga_horaria, c.versao, t.nome AS tema, tp.nome AS tipo FROM trilha_conteudos tc INNER JOIN conteudos c ON c.id = tc.conteudo_id INNER JOIN temas t ON t.id = c.tema_id INNER JOIN tipos_conteudo tp ON tp.id = c.tipo_id WHERE tc.trilha_id = ? ORDER BY tc.ordem ASC", [$trilhaId]); }
