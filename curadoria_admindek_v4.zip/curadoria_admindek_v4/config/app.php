<?php
return [
  'base_url' => '/curadoria',
  'app_name' => 'Curadoria Hub',
  'company_name' => 'Vivo',
  'logo_url' => '/curadoria/assets/img/logo-vivo.svg',
  'timezone' => 'America/Sao_Paulo',
  'theme_note' => 'Admindek-inspired enterprise shell with local assets'
];
