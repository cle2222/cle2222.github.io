<?php
return [
  'server' => 'NOME_DA_MAQUINA',
  'database' => 'CURADORIA',
  'user' => 'NOME_DA_MAQUINA',
  'pass' => '',
  'trusted_connection' => false,
  'drivers' => [
    '{ODBC Driver 18 for SQL Server}',
    '{ODBC Driver 17 for SQL Server}',
    '{ODBC Driver 13 for SQL Server}',
    '{SQL Server}',
  ],
  'options' => [
    'TrustServerCertificate' => 'yes',
    'Encrypt' => 'no',
  ],
];
