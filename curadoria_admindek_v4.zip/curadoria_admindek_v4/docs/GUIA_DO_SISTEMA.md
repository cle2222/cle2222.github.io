# Curadoria Hub V4 — Guia do sistema

## O que esta versão entrega
- PHP estrutural
- Bootstrap local dentro do projeto
- URL raiz: http://localhost/curadoria/
- SQL Server via ODBC com fallback de drivers
- Dashboard mais visual e com KPIs
- Cadastro com abas
- Versionamento com snapshot navegável
- Builder de trilha com drag and drop
- Copiloto conversacional local funcional
- Admin com mais módulos
- Popups e confirmações customizados
- Carga horária em formato hh:mm:ss

## Estrutura
- `.htaccess`
- `index.php`
- `login.php`
- `logout.php`
- `config/*`
- `inc/*`
- `assets/*`
- `pages/*`
- `sql/database.sql`

## Instalação
1. Copie a pasta para `C:\xampp\htdocs\curadoria`
2. Execute `sql/database.sql`
3. Ajuste `config/db.php`
4. Acesse `http://localhost/curadoria/login`
