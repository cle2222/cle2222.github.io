# Curadoria Hub V4

URL principal:
- http://localhost/curadoria/

Login de teste:
- 1001 / admin123
- 1002 / curador123
- 1003 / leitor123

Arquivos principais:
- sql/database.sql
- config/db.php
- docs/GUIA_DO_SISTEMA.md
