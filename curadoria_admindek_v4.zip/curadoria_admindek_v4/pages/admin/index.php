<?php
auth_require(); if(!auth_is_admin()){ flash_set('danger','Acesso restrito ao perfil Admin.'); redirect_to('/'); }
$modules=[
  ['slug'=>'temas','label'=>'Temas'],
  ['slug'=>'tipos_conteudo','label'=>'Tipos de conteúdo'],
  ['slug'=>'tags','label'=>'Tags'],
  ['slug'=>'areas_solicitantes','label'=>'Áreas solicitantes'],
  ['slug'=>'publicos','label'=>'Públicos'],
  ['slug'=>'status_conteudo','label'=>'Status de conteúdo'],
  ['slug'=>'categorias','label'=>'Categorias'],
  ['slug'=>'motivos_versao','label'=>'Motivos de versionamento'],
];
layout_header('Painel administrativo','Centro de parametrização do sistema.');
?>
<div class="row g-4">
<?php foreach($modules as $m): ?>
  <div class="col-md-6 col-xl-3"><a class="text-decoration-none" href="<?= h(url('/admin/' . $m['slug'])) ?>"><div class="metric-card"><div class="metric-value"><?= h(mb_substr($m['label'],0,2)) ?></div><div class="metric-label"><?= h($m['label']) ?></div><div class="metric-foot"><span class="soft-pill">Parametrizar</span></div></div></a></div>
<?php endforeach; ?>
</div>
<?php layout_footer(); ?>
