<?php
auth_require(); if(!auth_is_admin()){ flash_set('danger','Acesso restrito ao perfil Admin.'); redirect_to('/'); }
$table=basename(current_path());
$labels=['temas'=>'Temas','tipos_conteudo'=>'Tipos de conteúdo','tags'=>'Tags','areas_solicitantes'=>'Áreas solicitantes','publicos'=>'Públicos','status_conteudo'=>'Status de conteúdo','categorias'=>'Categorias','motivos_versao'=>'Motivos de versionamento'];
if(!isset($labels[$table])){ flash_set('danger','Módulo administrativo não encontrado.'); redirect_to('/admin'); }
if(is_post()){
  try{
    $action=ps('action');
    if($action==='create'){ $nome=trim(ps('nome')); if($nome==='') throw new Exception('Digite um nome.'); db_exec("INSERT INTO $table (nome, ativo) VALUES (?,1)",[$nome]); flash_set('success','Registro criado com sucesso.'); }
    elseif($action==='toggle'){ db_exec("UPDATE $table SET ativo = ? WHERE id = ?",[(int)ps('ativo'),(int)ps('id')]); flash_set('success','Registro atualizado com sucesso.'); }
    elseif($action==='delete'){ db_exec("DELETE FROM $table WHERE id = ?",[(int)ps('id')]); flash_set('success','Registro removido com sucesso.'); }
  } catch(Throwable $e){ flash_set('danger',$e->getMessage(),'Erro'); }
  redirect_to('/admin/' . $table);
}
$rows=repo_all($table);
layout_header($labels[$table],'CRUD administrativo para parametrização dinâmica.');
?>
<div class="row g-4">
  <div class="col-xl-4"><div class="app-form-shell"><div class="section-title mb-2">Novo registro</div><div class="section-subtitle mb-3">Use este formulário para adicionar um novo item.</div><form method="post"><input type="hidden" name="action" value="create"><div class="mb-3"><label class="form-label fw-semibold">Nome</label><input class="form-control" name="nome" required></div><div class="d-flex gap-2"><button class="btn app-btn-primary text-white">Adicionar</button><a class="btn btn-light border" href="<?= h(url('/admin')) ?>">Voltar</a></div></form></div></div>
  <div class="col-xl-8"><div class="card app-card"><div class="card-header p-4"><div class="fw-bold">Registros atuais</div><div class="text-secondary small"><?= count($rows) ?> item(ns)</div></div><div class="table-responsive"><table class="table app-table mb-0"><thead><tr><th>Nome</th><th>Status</th><th class="text-end">Ações</th></tr></thead><tbody><?php foreach($rows as $row): ?><tr><td><?= h($row['nome']) ?></td><td><?= ((int)$row['ativo']===1)?'<span class="soft-pill">Ativo</span>':'<span class="text-secondary">Inativo</span>' ?></td><td class="text-end"><form method="post" class="d-inline"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= h($row['id']) ?>"><input type="hidden" name="ativo" value="<?= ((int)$row['ativo']===1)?0:1 ?>"><button class="btn btn-sm btn-light border"><?= ((int)$row['ativo']===1)?'Desativar':'Ativar' ?></button></form> <form method="post" class="d-inline"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= h($row['id']) ?>"><button class="btn btn-sm btn-outline-danger" data-confirm="Tem certeza que deseja excluir este registro?">Excluir</button></form></td></tr><?php endforeach; ?><?php if(!$rows): ?><tr><td colspan="3" class="text-secondary">Nenhum registro cadastrado.</td></tr><?php endif; ?></tbody></table></div></div></div>
</div>
<?php layout_footer(); ?>
