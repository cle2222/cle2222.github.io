<?php
auth_require(); $q=trim(qs('q')); $params=[]; $where='';
if($q!==''){ $where="WHERE (c.nome LIKE ? OR l.acao LIKE ? OR l.entidade LIKE ?)"; $params=["%$q%","%$q%","%$q%"]; }
$rows=db_all("SELECT TOP 150 l.criado_em, c.nome AS usuario, l.acao, l.entidade, l.entidade_id FROM logs_auditoria l LEFT JOIN colaboradores c ON c.id = l.usuario_id $where ORDER BY l.criado_em DESC", $params);
layout_header('Logs e auditoria','Rastreabilidade das principais ações do sistema.');
?>
<div class="app-form-shell mb-4"><form class="row g-3 align-items-end"><div class="col-md-8 col-xl-6"><label class="form-label fw-semibold">Buscar</label><input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Usuário, ação ou entidade"></div><div class="col-md-auto d-flex gap-2"><button class="btn app-btn-primary text-white px-4">Buscar</button><a class="btn btn-light border px-4" href="<?= h(url('/logs')) ?>">Limpar</a></div></form></div>
<div class="card app-card"><div class="card-header p-4"><div class="fw-bold">Últimos registros</div><div class="text-secondary small"><?= count($rows) ?> item(ns)</div></div><div class="table-responsive"><table class="table app-table mb-0"><thead><tr><th>Data</th><th>Usuário</th><th>Ação</th><th>Entidade</th><th>ID</th></tr></thead><tbody><?php foreach($rows as $row): ?><tr><td><?= h($row['criado_em']) ?></td><td><?= h($row['usuario']) ?></td><td><?= h($row['acao']) ?></td><td><?= h($row['entidade']) ?></td><td><?= h($row['entidade_id']) ?></td></tr><?php endforeach; ?><?php if(!$rows): ?><tr><td colspan="5" class="text-secondary">Nenhum log encontrado.</td></tr><?php endif; ?></tbody></table></div></div>
<?php layout_footer(); ?>
