<?php
require_once __DIR__ . '/../../inc/bootstrap.php';
auth_require(); header('Content-Type: application/json; charset=utf-8');
try{
  $prompt=trim(qs('prompt')); $temaId=(int)qs('tema_id',0); $exclude=trim(qs('exclude','')); $excludeIds=array_values(array_filter(array_map('intval',explode(',',$exclude))));
  if($prompt==='') throw new Exception('Prompt obrigatório.');
  echo json_encode(['ok'=>true,'payload'=>ai_copilot_reply($prompt,$temaId,$excludeIds)], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}catch(Throwable $e){ echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }
