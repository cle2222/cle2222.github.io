<?php
require_once __DIR__ . '/../../inc/bootstrap.php';
auth_require(); header('Content-Type: application/json; charset=utf-8');
try{
  $temaId=(int)qs('tema_id',0); $exclude=trim(qs('exclude','')); $excludeIds=array_values(array_filter(array_map('intval',explode(',',$exclude))));
  if($temaId<=0) throw new Exception('tema_id obrigatório.');
  echo json_encode(['ok'=>true,'items'=>ai_auto_trilha($temaId,$excludeIds)], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}catch(Throwable $e){ echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); }
