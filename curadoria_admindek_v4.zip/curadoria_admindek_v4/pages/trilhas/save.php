<?php
auth_require(); $user=auth_user(); $id=(int)qs('id',0); $isEdit=$id>0; $nome=trim(ps('nome')); $temaId=(int)ps('tema_id');
$conteudos=json_decode(ps('conteudos_json','[]'), true); $conteudos=is_array($conteudos)?array_values(array_filter(array_map('intval',$conteudos))):[];
try{
  if($nome==='' || $temaId<=0) throw new Exception('Preencha o nome e o tema da trilha.');
  if(!$isEdit){
    db_exec("INSERT INTO trilhas (nome,tema_id,criado_por,criado_em,ativo) VALUES (?,?,?,GETDATE(),1)", [$nome,$temaId,$user['id']]);
    $id=(int)(db_scalar("SELECT TOP 1 id FROM trilhas WHERE criado_por = ? ORDER BY id DESC",[$user['id']]) ?? 0);
    db_exec("INSERT INTO logs_auditoria (usuario_id,acao,entidade,entidade_id,criado_em) VALUES (?, 'CREATE', 'TRILHA', ?, GETDATE())",[$user['id'],$id]);
  } else {
    db_exec("UPDATE trilhas SET nome=?, tema_id=?, atualizado_por=?, atualizado_em=GETDATE() WHERE id=?", [$nome,$temaId,$user['id'],$id]);
    db_exec("DELETE FROM trilha_conteudos WHERE trilha_id = ?",[$id]);
    db_exec("INSERT INTO logs_auditoria (usuario_id,acao,entidade,entidade_id,criado_em) VALUES (?, 'UPDATE', 'TRILHA', ?, GETDATE())",[$user['id'],$id]);
  }
  $ord=1; foreach($conteudos as $cid) db_exec("INSERT INTO trilha_conteudos (trilha_id,conteudo_id,ordem) VALUES (?,?,?)", [$id,$cid,$ord++]);
  flash_set('success','Trilha salva com sucesso.'); redirect_to('/trilhas');
}catch(Throwable $e){ flash_set('danger',$e->getMessage(),'Erro ao salvar trilha'); redirect_to('/trilhas'); }
