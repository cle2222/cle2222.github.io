<?php
auth_require(); $rows=db_all("SELECT tr.id, tr.nome, t.nome AS tema, tr.criado_em FROM trilhas tr INNER JOIN temas t ON t.id = tr.tema_id WHERE tr.ativo = 1 ORDER BY tr.criado_em DESC");
layout_header('Trilhas de treinamento','Monte trilhas com drag and drop e use o copiloto local.');
?>
<div class="d-flex justify-content-end mb-4"><a class="btn app-btn-primary text-white px-4" href="<?= h(url('/trilhas/builder')) ?>">+ Nova trilha</a></div>
<div class="card app-card"><div class="card-header p-4"><div class="fw-bold">Trilhas cadastradas</div><div class="text-secondary small">Acesse para revisar, editar ou usar a sugestão automática.</div></div><div class="table-responsive"><table class="table app-table mb-0"><thead><tr><th>Nome</th><th>Tema</th><th>Criada em</th><th class="text-end">Ações</th></tr></thead><tbody>
<?php foreach($rows as $row): ?><tr><td><?= h($row['nome']) ?></td><td><?= h($row['tema']) ?></td><td><?= h($row['criado_em']) ?></td><td class="text-end"><a class="btn btn-sm app-btn-primary text-white" href="<?= h(url('/trilhas/builder?id=' . $row['id'])) ?>">Abrir builder</a></td></tr><?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="4" class="text-secondary">Nenhuma trilha criada até o momento.</td></tr><?php endif; ?>
</tbody></table></div></div>
<?php layout_footer(); ?>
