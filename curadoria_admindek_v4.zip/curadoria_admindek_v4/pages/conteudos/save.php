<?php
auth_require(); $user=auth_user(); $id=(int)qs('id',0); $isEdit=$id>0;
$titulo=trim(ps('titulo')); $descricao=trim(ps('descricao')); $link=trim(ps('link_url')); $temaId=(int)ps('tema_id'); $tipoId=(int)ps('tipo_id');
$categoriaId=ps('categoria_id')===''?null:(int)ps('categoria_id'); $publicoId=ps('publico_id')===''?null:(int)ps('publico_id'); $statusId=ps('status_id')===''?null:(int)ps('status_id');
$b2x=trim(ps('b2x')); $origem=trim(ps('origem_material')); $carga=trim(ps('carga_horaria')); $areaSolic=ps('area_solicitante_id')===''?null:(int)ps('area_solicitante_id');
$tags=ps('tags',[]); $tags=is_array($tags)?array_values(array_filter(array_map('intval',$tags))):[];
$ticketAreas=ps('ticket_area',[]); $ticketNums=ps('ticket_numero',[]); $ticketObs=ps('ticket_obs',[]);
$tickets=[]; if(is_array($ticketAreas)&&is_array($ticketNums)&&is_array($ticketObs)){ $limit=min(count($ticketAreas),count($ticketNums),count($ticketObs)); for($i=0;$i<$limit;$i++){ $a=(int)$ticketAreas[$i]; $n=trim((string)$ticketNums[$i]); $o=trim((string)$ticketObs[$i]); if($a>0 && $n!=='') $tickets[]=['area_id'=>$a,'numero'=>$n,'observacao'=>$o]; } }
$motivo=trim(ps('motivo_versao')); if($motivo==='') $motivo=trim(ps('observacao_governanca'));
try{
  if($titulo==='' || $temaId<=0 || $tipoId<=0) throw new Exception('Preencha Título, Tema e Tipo.');
  if(!preg_match('/^\d{2}:\d{2}:\d{2}$/',$carga)) throw new Exception('A carga horária deve estar no formato hh:mm:ss.');
  if(!$isEdit){
    db_exec("INSERT INTO conteudos (titulo,descricao,link_url,tema_id,tipo_id,categoria_id,publico_id,status_id,b2x,origem_material,carga_horaria,area_solicitante_id,versao,criado_por,criado_em,ativo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,?,GETDATE(),1)",
      [$titulo,$descricao,$link,$temaId,$tipoId,$categoriaId,$publicoId,$statusId,$b2x,$origem,$carga,$areaSolic,$user['id']]);
    $newId=(int)(db_scalar("SELECT TOP 1 id FROM conteudos WHERE criado_por = ? ORDER BY id DESC",[$user['id']]) ?? 0);
    foreach($tags as $tagId) db_exec("INSERT INTO conteudo_tags (conteudo_id,tag_id) VALUES (?,?)",[$newId,$tagId]);
    foreach($tickets as $t) db_exec("INSERT INTO conteudo_chamados (conteudo_id,area_id,numero,observacao) VALUES (?,?,?,?)",[$newId,$t['area_id'],$t['numero'],$t['observacao']]);
    db_exec("INSERT INTO logs_auditoria (usuario_id,acao,entidade,entidade_id,criado_em) VALUES (?, 'CREATE', 'CONTEUDO', ?, GETDATE())",[$user['id'],$newId]);
    flash_set('success','Conteúdo cadastrado com sucesso.'); redirect_to('/conteudos');
  }
  $current=db_one("SELECT * FROM conteudos WHERE id = ? AND ativo = 1",[$id]); if(!$current) throw new Exception('Conteúdo não encontrado para edição.');
  $snap=json_encode(['conteudo'=>$current,'tags'=>db_all('SELECT tag_id FROM conteudo_tags WHERE conteudo_id = ?',[$id]),'tickets'=>db_all('SELECT area_id,numero,observacao FROM conteudo_chamados WHERE conteudo_id = ?',[$id])], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  db_exec("INSERT INTO conteudos_versoes (conteudo_id,versao,motivo,dados_json,criado_por,criado_em) VALUES (?,?,?,?,?,GETDATE())",[$id,$current['versao'],$motivo,$snap,$user['id']]);
  db_exec("UPDATE conteudos SET titulo=?,descricao=?,link_url=?,tema_id=?,tipo_id=?,categoria_id=?,publico_id=?,status_id=?,b2x=?,origem_material=?,carga_horaria=?,area_solicitante_id=?,versao=versao+1,atualizado_por=?,atualizado_em=GETDATE() WHERE id=?",
    [$titulo,$descricao,$link,$temaId,$tipoId,$categoriaId,$publicoId,$statusId,$b2x,$origem,$carga,$areaSolic,$user['id'],$id]);
  db_exec("DELETE FROM conteudo_tags WHERE conteudo_id = ?",[$id]); foreach($tags as $tagId) db_exec("INSERT INTO conteudo_tags (conteudo_id,tag_id) VALUES (?,?)",[$id,$tagId]);
  db_exec("DELETE FROM conteudo_chamados WHERE conteudo_id = ?",[$id]); foreach($tickets as $t) db_exec("INSERT INTO conteudo_chamados (conteudo_id,area_id,numero,observacao) VALUES (?,?,?,?)",[$id,$t['area_id'],$t['numero'],$t['observacao']]);
  db_exec("INSERT INTO logs_auditoria (usuario_id,acao,entidade,entidade_id,criado_em) VALUES (?, 'UPDATE', 'CONTEUDO', ?, GETDATE())",[$user['id'],$id]);
  flash_set('success','Conteúdo atualizado com sucesso. A versão anterior foi arquivada.'); redirect_to('/conteudos');
}catch(Throwable $e){ flash_set('danger',$e->getMessage(),'Erro ao salvar'); redirect_to('/conteudos'); }
