<?php
auth_require(); $id=(int)qs('id',0); $item=db_one("SELECT titulo, versao FROM conteudos WHERE id = ? AND ativo = 1",[$id]);
if(!$item){ flash_set('danger','Conteúdo não encontrado.'); redirect_to('/conteudos'); }
$versions=db_all("SELECT v.id, v.versao, v.motivo, v.criado_em, c.nome AS usuario FROM conteudos_versoes v LEFT JOIN colaboradores c ON c.id = v.criado_por WHERE v.conteudo_id = ? ORDER BY v.versao DESC",[$id]);
layout_header('Histórico de versões','Conteúdo: ' . $item['titulo']);
?>
<div class="card app-card"><div class="card-header p-4 d-flex justify-content-between align-items-center"><div><div class="fw-bold"><?= h($item['titulo']) ?></div><div class="text-secondary small">Versão atual: v<?= h($item['versao']) ?></div></div><a class="btn btn-light border" href="<?= h(url('/conteudos')) ?>">Voltar</a></div><div class="table-responsive"><table class="table app-table mb-0"><thead><tr><th>Versão</th><th>Criada em</th><th>Usuário</th><th>Motivo</th><th class="text-end">Ações</th></tr></thead><tbody>
<?php foreach($versions as $row): ?><tr><td><span class="soft-pill">v<?= h($row['versao']) ?></span></td><td><?= h($row['criado_em']) ?></td><td><?= h($row['usuario']) ?></td><td><?= h($row['motivo']) ?></td><td class="text-end"><a class="btn btn-sm btn-light border" href="<?= h(url('/conteudos/versao?id=' . $row['id'])) ?>">Abrir snapshot</a></td></tr><?php endforeach; ?>
<?php if(!$versions): ?><tr><td colspan="5" class="text-secondary">Ainda não existem versões arquivadas.</td></tr><?php endif; ?>
</tbody></table></div></div>
<?php layout_footer(); ?>
