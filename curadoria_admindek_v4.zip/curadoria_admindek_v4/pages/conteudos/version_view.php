<?php
auth_require(); $versionId=(int)qs('id',0); $version=repo_version_detail($versionId);
if(!$version){ flash_set('danger','Versão não encontrada.'); redirect_to('/conteudos'); }
$dados=$version['dados'] ?? []; $conteudo=$dados['conteudo'] ?? []; $tags=$dados['tags'] ?? []; $tickets=$dados['tickets'] ?? [];
layout_header('Snapshot da versão','Versão v' . ($version['versao'] ?? '') . ' • ' . ($version['usuario'] ?? ''));
?>
<div class="row g-4">
  <div class="col-xl-8"><div class="app-form-shell"><div class="section-title mb-3">Metadados da versão</div><div class="row g-3">
    <div class="col-md-6"><div class="text-secondary small">Título</div><div class="fw-semibold"><?= h($conteudo['titulo'] ?? '') ?></div></div>
    <div class="col-md-6"><div class="text-secondary small">Link</div><div class="fw-semibold"><?= h($conteudo['link_url'] ?? '') ?></div></div>
    <div class="col-md-3"><div class="text-secondary small">Tema ID</div><div class="fw-semibold"><?= h($conteudo['tema_id'] ?? '') ?></div></div>
    <div class="col-md-3"><div class="text-secondary small">Tipo ID</div><div class="fw-semibold"><?= h($conteudo['tipo_id'] ?? '') ?></div></div>
    <div class="col-md-3"><div class="text-secondary small">Categoria ID</div><div class="fw-semibold"><?= h($conteudo['categoria_id'] ?? '') ?></div></div>
    <div class="col-md-3"><div class="text-secondary small">Público ID</div><div class="fw-semibold"><?= h($conteudo['publico_id'] ?? '') ?></div></div>
    <div class="col-md-4"><div class="text-secondary small">Status ID</div><div class="fw-semibold"><?= h($conteudo['status_id'] ?? '') ?></div></div>
    <div class="col-md-4"><div class="text-secondary small">B2B/B2C</div><div class="fw-semibold"><?= h($conteudo['b2x'] ?? '') ?></div></div>
    <div class="col-md-4"><div class="text-secondary small">Carga horária</div><div class="fw-semibold"><?= h($conteudo['carga_horaria'] ?? '') ?></div></div>
    <div class="col-12"><div class="text-secondary small">Descrição</div><div><?= nl2br(h($conteudo['descricao'] ?? '')) ?></div></div>
  </div></div></div>
  <div class="col-xl-4">
    <div class="app-form-shell mb-4"><div class="section-title mb-3">Tags da época</div><div class="d-flex flex-wrap gap-2"><?php foreach($tags as $row): ?><span class="soft-pill">#<?= h($row['tag_id'] ?? '') ?></span><?php endforeach; ?><?php if(!$tags): ?><div class="text-secondary">Sem tags.</div><?php endif; ?></div></div>
    <div class="app-form-shell"><div class="section-title mb-3">Chamados da época</div><?php foreach($tickets as $t): ?><div class="border rounded-4 p-3 mb-2"><div class="fw-semibold"><?= h($t['numero'] ?? '') ?></div><div class="text-secondary small">Área ID: <?= h($t['area_id'] ?? '') ?></div><div class="small"><?= h($t['observacao'] ?? '') ?></div></div><?php endforeach; ?><?php if(!$tickets): ?><div class="text-secondary">Sem chamados.</div><?php endif; ?></div>
  </div>
</div>
<div class="mt-4"><a class="btn btn-light border" href="<?= h(url('/conteudos/versoes?id=' . ($version['conteudo_id'] ?? 0))) ?>">Voltar ao histórico</a></div>
<?php layout_footer(); ?>
