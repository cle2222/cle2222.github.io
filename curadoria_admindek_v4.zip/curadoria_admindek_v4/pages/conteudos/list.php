<?php
auth_require();
$busca=trim(qs('q')); $params=[]; $where="WHERE c.ativo = 1";
if($busca!==''){ $where .= " AND (c.titulo LIKE ? OR c.descricao LIKE ?)"; $params[]="%$busca%"; $params[]="%$busca%"; }
$rows=db_all("SELECT c.id, c.titulo, c.link_url, c.carga_horaria, c.versao, t.nome AS tema, tp.nome AS tipo, a.nome AS area FROM conteudos c INNER JOIN temas t ON t.id = c.tema_id INNER JOIN tipos_conteudo tp ON tp.id = c.tipo_id LEFT JOIN areas_solicitantes a ON a.id = c.area_solicitante_id $where ORDER BY c.criado_em DESC", $params);
layout_header('Banco de conteúdos','Catálogo central de tudo o que já foi curado e pode compor trilhas.');
?>
<div class="d-flex flex-column flex-lg-row gap-3 justify-content-between align-items-lg-end mb-4">
  <form class="row g-2 w-100" method="get" action="<?= h(url('/conteudos')) ?>">
    <div class="col-md-8 col-xl-6"><label class="form-label fw-semibold">Busca</label><input class="form-control form-control-lg" name="q" value="<?= h($busca) ?>" placeholder="Digite parte do título ou da descrição"></div>
    <div class="col-md-auto d-flex align-items-end gap-2"><button class="btn app-btn-primary text-white px-4">Buscar</button><a class="btn btn-light border px-4" href="<?= h(url('/conteudos')) ?>">Limpar</a></div>
  </form>
  <a class="btn app-btn-primary text-white px-4" href="<?= h(url('/conteudos/novo')) ?>">+ Novo conteúdo</a>
</div>

<div class="card app-card"><div class="card-header p-4"><div class="fw-bold">Lista de conteúdos</div><div class="text-secondary small"><?= count($rows) ?> registro(s) encontrado(s)</div></div><div class="table-responsive"><table class="table app-table mb-0"><thead><tr><th>Título</th><th>Link</th><th>Tema</th><th>Área</th><th>Tipo</th><th>Duração</th><th>Versão</th><th class="text-end">Ações</th></tr></thead><tbody>
<?php foreach($rows as $row): ?><tr><td><div class="fw-semibold"><?= h($row['titulo']) ?></div></td><td><?php if(!empty($row['link_url'])): ?><a class="btn btn-sm btn-light border" target="_blank" href="<?= h($row['link_url']) ?>">Abrir</a><?php else: ?><span class="text-secondary">—</span><?php endif; ?></td><td><?= h($row['tema']) ?></td><td><?= h($row['area']) ?></td><td><?= h($row['tipo']) ?></td><td><?= h($row['carga_horaria']) ?></td><td><span class="soft-pill">v<?= h($row['versao']) ?></span></td><td class="text-end"><a class="btn btn-sm btn-light border" href="<?= h(url('/conteudos/versoes?id=' . $row['id'])) ?>">Versões</a> <a class="btn btn-sm app-btn-primary text-white" href="<?= h(url('/conteudos/editar?id=' . $row['id'])) ?>">Editar</a></td></tr><?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="8" class="text-secondary">Nenhum conteúdo encontrado.</td></tr><?php endif; ?>
</tbody></table></div></div>
<?php layout_footer(); ?>
