<?php
auth_require();
$id=(int)qs('id',0); $isEdit=$id>0;
$conteudo=['titulo'=>'','descricao'=>'','link_url'=>'','tema_id'=>'','tipo_id'=>'','categoria_id'=>'','publico_id'=>'','status_id'=>'','b2x'=>'','origem_material'=>'','carga_horaria'=>'00:10:00','area_solicitante_id'=>''];
$conteudoTags=[]; $conteudoChamados=[];
if($isEdit){
  $conteudo=db_one("SELECT * FROM conteudos WHERE id = ? AND ativo = 1", [$id]);
  if(!$conteudo){ flash_set('danger','Conteúdo não encontrado.'); redirect_to('/conteudos'); }
  $conteudoTags=repo_content_tags($id);
  $conteudoChamados=repo_content_tickets($id);
}
$temas=repo_all_active('temas'); $tipos=repo_all_active('tipos_conteudo'); $tags=repo_all_active('tags'); $areas=repo_all_active('areas_solicitantes');
$publicos=repo_all_active('publicos'); $status=repo_all_active('status_conteudo'); $categorias=repo_all_active('categorias'); $motivos=repo_all_active('motivos_versao');
layout_header($isEdit ? 'Editar conteúdo' : 'Novo conteúdo','Formulário em abas para cadastro, classificação, chamados e governança.');
?>
<form method="post" action="<?= h(url($isEdit ? '/conteudos/editar?id=' . $id : '/conteudos/novo')) ?>">
<div class="app-form-shell">
  <ul class="nav nav-tabs mb-4" role="tablist">
    <li class="nav-item"><button class="nav-link active" type="button" data-bs-toggle="tab" data-bs-target="#tab-ident">Identificação</button></li>
    <li class="nav-item"><button class="nav-link" type="button" data-bs-toggle="tab" data-bs-target="#tab-class">Classificação</button></li>
    <li class="nav-item"><button class="nav-link" type="button" data-bs-toggle="tab" data-bs-target="#tab-chamados">Chamados</button></li>
    <li class="nav-item"><button class="nav-link" type="button" data-bs-toggle="tab" data-bs-target="#tab-gov">Governança</button></li>
  </ul>
  <div class="tab-content">
    <div class="tab-pane fade show active" id="tab-ident">
      <div class="row g-3">
        <div class="col-12"><label class="form-label fw-semibold">Título *</label><input class="form-control form-control-lg" name="titulo" required value="<?= h($conteudo['titulo']) ?>"></div>
        <div class="col-md-6"><label class="form-label fw-semibold">Tema *</label><select class="form-select form-select-lg" name="tema_id" required><option value="">Selecione</option><?php foreach($temas as $i): ?><option value="<?= h($i['id']) ?>" <?= ((string)$conteudo['tema_id']===(string)$i['id'])?'selected':'' ?>><?= h($i['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-6"><label class="form-label fw-semibold">Tipo *</label><select class="form-select form-select-lg" name="tipo_id" required><option value="">Selecione</option><?php foreach($tipos as $i): ?><option value="<?= h($i['id']) ?>" <?= ((string)$conteudo['tipo_id']===(string)$i['id'])?'selected':'' ?>><?= h($i['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-6"><label class="form-label fw-semibold">Link do conteúdo</label><input class="form-control" name="link_url" value="<?= h($conteudo['link_url']) ?>" placeholder="https://..."></div>
        <div class="col-md-3"><label class="form-label fw-semibold">Carga horária (hh:mm:ss)</label><input class="form-control" name="carga_horaria" value="<?= h($conteudo['carga_horaria']) ?>" placeholder="00:30:00"></div>
        <div class="col-md-3"><label class="form-label fw-semibold">Origem do material</label><input class="form-control" name="origem_material" value="<?= h($conteudo['origem_material']) ?>" placeholder="LMS, SharePoint..."></div>
        <div class="col-12"><label class="form-label fw-semibold">Descrição</label><textarea class="form-control" rows="6" name="descricao"><?= h($conteudo['descricao']) ?></textarea></div>
      </div>
    </div>

    <div class="tab-pane fade" id="tab-class">
      <div class="row g-3">
        <div class="col-md-4"><label class="form-label fw-semibold">Categoria</label><select class="form-select" name="categoria_id"><option value="">Selecione</option><?php foreach($categorias as $i): ?><option value="<?= h($i['id']) ?>" <?= ((string)$conteudo['categoria_id']===(string)$i['id'])?'selected':'' ?>><?= h($i['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-4"><label class="form-label fw-semibold">Público</label><select class="form-select" name="publico_id"><option value="">Selecione</option><?php foreach($publicos as $i): ?><option value="<?= h($i['id']) ?>" <?= ((string)$conteudo['publico_id']===(string)$i['id'])?'selected':'' ?>><?= h($i['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-4"><label class="form-label fw-semibold">Status</label><select class="form-select" name="status_id"><option value="">Selecione</option><?php foreach($status as $i): ?><option value="<?= h($i['id']) ?>" <?= ((string)$conteudo['status_id']===(string)$i['id'])?'selected':'' ?>><?= h($i['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-4"><label class="form-label fw-semibold">B2B / B2C</label><select class="form-select" name="b2x"><option value="">Selecione</option><option value="B2B" <?= $conteudo['b2x']==='B2B'?'selected':'' ?>>B2B</option><option value="B2C" <?= $conteudo['b2x']==='B2C'?'selected':'' ?>>B2C</option></select></div>
        <div class="col-md-8"><label class="form-label fw-semibold">Área solicitante</label><select class="form-select" name="area_solicitante_id"><option value="">Selecione</option><?php foreach($areas as $i): ?><option value="<?= h($i['id']) ?>" <?= ((string)$conteudo['area_solicitante_id']===(string)$i['id'])?'selected':'' ?>><?= h($i['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="col-12"><label class="form-label fw-semibold">Tags</label><div class="d-flex flex-wrap gap-2"><?php foreach($tags as $i): ?><label class="soft-pill"><input class="form-check-input mt-0 me-1" type="checkbox" name="tags[]" value="<?= h($i['id']) ?>" <?= in_array((int)$i['id'],$conteudoTags,true)?'checked':'' ?>><?= h($i['nome']) ?></label><?php endforeach; ?></div></div>
      </div>
    </div>

    <div class="tab-pane fade" id="tab-chamados">
      <div class="d-flex justify-content-between align-items-center mb-3"><div><div class="section-title">Chamados por área</div><div class="section-subtitle">Vários chamados podem existir no mesmo conteúdo.</div></div><button type="button" id="addChamado" class="btn btn-light border">+ Adicionar chamado</button></div>
      <div id="ticketsBox"><?php $rows=$conteudoChamados ?: [['area_id'=>'','numero'=>'','observacao'=>'']]; foreach($rows as $row): ?><div class="border rounded-4 p-3 mb-3 ticket-row"><div class="row g-3"><div class="col-md-4"><label class="form-label fw-semibold small">Área</label><select class="form-select" name="ticket_area[]"><option value="">Selecione</option><?php foreach($areas as $area): ?><option value="<?= h($area['id']) ?>" <?= ((string)$row['area_id']===(string)$area['id'])?'selected':'' ?>><?= h($area['nome']) ?></option><?php endforeach; ?></select></div><div class="col-md-4"><label class="form-label fw-semibold small">Número</label><input class="form-control" name="ticket_numero[]" value="<?= h($row['numero']) ?>" placeholder="Ex.: RH-8891"></div><div class="col-md-4"><label class="form-label fw-semibold small">Observação</label><div class="input-group"><input class="form-control" name="ticket_obs[]" value="<?= h($row['observacao']) ?>" placeholder="Observação opcional"><button class="btn btn-outline-danger removeTicket" type="button">Remover</button></div></div></div></div><?php endforeach; ?></div>
    </div>

    <div class="tab-pane fade" id="tab-gov">
      <div class="row g-3">
        <div class="col-md-6"><label class="form-label fw-semibold">Motivo da alteração</label><select class="form-select" name="motivo_versao"><option value="">Selecione</option><?php foreach($motivos as $i): ?><option value="<?= h($i['nome']) ?>"><?= h($i['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-6"><label class="form-label fw-semibold">Observação adicional</label><input class="form-control" name="observacao_governanca" placeholder="Opcional"></div>
        <div class="col-12"><div class="summary-card"><div class="fw-semibold mb-2">Como funciona o versionamento</div><div class="text-secondary">Ao editar um conteúdo, a versão anterior é arquivada com snapshot completo de metadados, tags e chamados.</div></div></div>
      </div>
    </div>
  </div>
</div>
<div class="d-flex justify-content-end gap-2 mt-4"><a class="btn btn-light border px-4" href="<?= h(url('/conteudos')) ?>">Cancelar</a><button class="btn app-btn-primary text-white px-4"><?= $isEdit ? 'Salvar nova versão' : 'Cadastrar conteúdo' ?></button></div>
</form>
<script>
(()=>{const box=document.getElementById('ticketsBox');const btn=document.getElementById('addChamado');
function bindRemove(el){el.addEventListener('click',()=>{if(box.querySelectorAll('.ticket-row').length>1) el.closest('.ticket-row').remove();});}
box.querySelectorAll('.removeTicket').forEach(bindRemove);
btn.addEventListener('click',()=>{const row=document.createElement('div');row.className='border rounded-4 p-3 mb-3 ticket-row';row.innerHTML=`<div class="row g-3"><div class="col-md-4"><label class="form-label fw-semibold small">Área</label><select class="form-select" name="ticket_area[]"><option value="">Selecione</option><?php foreach($areas as $area): ?><option value="<?= h($area['id']) ?>"><?= h($area['nome']) ?></option><?php endforeach; ?></select></div><div class="col-md-4"><label class="form-label fw-semibold small">Número</label><input class="form-control" name="ticket_numero[]" placeholder="Ex.: RH-8891"></div><div class="col-md-4"><label class="form-label fw-semibold small">Observação</label><div class="input-group"><input class="form-control" name="ticket_obs[]" placeholder="Observação opcional"><button class="btn btn-outline-danger removeTicket" type="button">Remover</button></div></div></div>`;box.appendChild(row);bindRemove(row.querySelector('.removeTicket'));});})();
</script>
<?php layout_footer(); ?>
