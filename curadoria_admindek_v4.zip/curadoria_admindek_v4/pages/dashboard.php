<?php
auth_require();
$totalConteudos=(int)(db_scalar("SELECT COUNT(*) AS n FROM conteudos WHERE ativo = 1",[],'n') ?? 0);
$totalTrilhas=(int)(db_scalar("SELECT COUNT(*) AS n FROM trilhas WHERE ativo = 1",[],'n') ?? 0);
$totalVersoes=(int)(db_scalar("SELECT COUNT(*) AS n FROM conteudos_versoes",[],'n') ?? 0);
$alteracoes7d=(int)(db_scalar("SELECT COUNT(*) AS n FROM logs_auditoria WHERE criado_em >= DATEADD(DAY,-7,GETDATE())",[],'n') ?? 0);
$cargaTotal=db_all("SELECT carga_horaria FROM conteudos WHERE ativo = 1"); $segTotal=0; foreach($cargaTotal as $r){ $segTotal += hms_to_seconds($r['carga_horaria']); }
$maisUsados=db_all("SELECT TOP 8 c.titulo, COUNT(*) AS usos FROM trilha_conteudos tc INNER JOIN conteudos c ON c.id = tc.conteudo_id GROUP BY c.titulo ORDER BY usos DESC");
$porTema=db_all("SELECT t.nome, COUNT(*) AS total FROM conteudos c INNER JOIN temas t ON t.id = c.tema_id WHERE c.ativo = 1 GROUP BY t.nome ORDER BY total DESC");
$porTipo=db_all("SELECT tp.nome, COUNT(*) AS total FROM conteudos c INNER JOIN tipos_conteudo tp ON tp.id = c.tipo_id WHERE c.ativo = 1 GROUP BY tp.nome ORDER BY total DESC");
$semUso=db_all("SELECT TOP 8 c.titulo FROM conteudos c LEFT JOIN trilha_conteudos tc ON tc.conteudo_id = c.id WHERE c.ativo = 1 GROUP BY c.id, c.titulo HAVING COUNT(tc.id)=0 ORDER BY c.titulo");
$ultimosLogs=db_all("SELECT TOP 10 l.criado_em, c.nome AS usuario, l.acao, l.entidade, l.entidade_id FROM logs_auditoria l LEFT JOIN colaboradores c ON c.id = l.usuario_id ORDER BY l.criado_em DESC");
$maxTema=1; foreach($porTema as $r){ $maxTema=max($maxTema,(int)$r['total']); }
$maxTipo=1; foreach($porTipo as $r){ $maxTipo=max($maxTipo,(int)$r['total']); }
layout_header('Dashboard executivo','Visão geral do banco de conteúdos, trilhas, carga horária e governança.');
?>
<div class="row g-4 mb-4">
  <div class="col-md-6 col-xl-3"><div class="metric-card"><div class="metric-value"><?= h($totalConteudos) ?></div><div class="metric-label">Conteúdos ativos</div><div class="metric-foot"><span class="soft-pill">Banco curado</span></div></div></div>
  <div class="col-md-6 col-xl-3"><div class="metric-card"><div class="metric-value"><?= h($totalTrilhas) ?></div><div class="metric-label">Trilhas cadastradas</div><div class="metric-foot"><span class="soft-pill">Builder visual</span></div></div></div>
  <div class="col-md-6 col-xl-3"><div class="metric-card"><div class="metric-value"><?= h($totalVersoes) ?></div><div class="metric-label">Snapshots de versão</div><div class="metric-foot"><span class="soft-pill">Auditoria</span></div></div></div>
  <div class="col-md-6 col-xl-3"><div class="metric-card"><div class="metric-value"><?= h(seconds_to_hms($segTotal)) ?></div><div class="metric-label">Carga horária total do banco</div><div class="metric-foot"><span class="soft-pill">Formato hh:mm:ss</span></div></div></div>
</div>

<div class="row g-4">
  <div class="col-xl-6"><div class="card app-card h-100"><div class="card-header p-4"><div class="fw-bold">Conteúdos por tema</div><div class="text-secondary small">Onde está a maior massa de materiais.</div></div><div class="card-body p-4"><div class="chart-bars"><?php foreach($porTema as $row): $pct=round(((int)$row['total']/$maxTema)*100); ?><div class="chart-row"><div class="fw-semibold"><?= h($row['nome']) ?></div><div class="chart-track"><div class="chart-fill" style="width: <?= $pct ?>%"></div></div><div class="text-secondary text-end"><?= h($row['total']) ?></div></div><?php endforeach; ?><?php if(!$porTema): ?><div class="text-secondary">Sem dados.</div><?php endif; ?></div></div></div></div>
  <div class="col-xl-6"><div class="card app-card h-100"><div class="card-header p-4"><div class="fw-bold">Conteúdos por tipo</div><div class="text-secondary small">Mix de formatos disponíveis no catálogo.</div></div><div class="card-body p-4"><div class="chart-bars"><?php foreach($porTipo as $row): $pct=round(((int)$row['total']/$maxTipo)*100); ?><div class="chart-row"><div class="fw-semibold"><?= h($row['nome']) ?></div><div class="chart-track"><div class="chart-fill" style="width: <?= $pct ?>%"></div></div><div class="text-secondary text-end"><?= h($row['total']) ?></div></div><?php endforeach; ?><?php if(!$porTipo): ?><div class="text-secondary">Sem dados.</div><?php endif; ?></div></div></div></div>
</div>

<div class="row g-4 mt-1">
  <div class="col-xl-6"><div class="card app-card h-100"><div class="card-header p-4"><div class="fw-bold">Mais usados em trilhas</div><div class="text-secondary small">Conteúdos que viraram padrão operacional.</div></div><div class="card-body p-0"><table class="table app-table mb-0"><thead><tr><th>Conteúdo</th><th>Usos</th></tr></thead><tbody><?php foreach($maisUsados as $row): ?><tr><td><?= h($row['titulo']) ?></td><td><?= h($row['usos']) ?></td></tr><?php endforeach; ?><?php if(!$maisUsados): ?><tr><td colspan="2" class="text-secondary">Sem dados.</td></tr><?php endif; ?></tbody></table></div></div></div>
  <div class="col-xl-6"><div class="card app-card h-100"><div class="card-header p-4"><div class="fw-bold">Conteúdos sem uso</div><div class="text-secondary small">Oportunidade de revisão ou reaproveitamento.</div></div><div class="card-body p-0"><table class="table app-table mb-0"><thead><tr><th>Título</th></tr></thead><tbody><?php foreach($semUso as $row): ?><tr><td><?= h($row['titulo']) ?></td></tr><?php endforeach; ?><?php if(!$semUso): ?><tr><td class="text-secondary">Todos os conteúdos já foram usados ao menos uma vez.</td></tr><?php endif; ?></tbody></table></div></div></div>
</div>

<div class="card app-card mt-4"><div class="card-header p-4"><div class="fw-bold">Últimas atividades</div><div class="text-secondary small">Quem fez o quê e quando.</div></div><div class="card-body p-0"><table class="table app-table mb-0"><thead><tr><th>Data</th><th>Usuário</th><th>Ação</th><th>Entidade</th><th>ID</th></tr></thead><tbody><?php foreach($ultimosLogs as $row): ?><tr><td><?= h($row['criado_em']) ?></td><td><?= h($row['usuario'] ?: 'Sistema') ?></td><td><?= h($row['acao']) ?></td><td><?= h($row['entidade']) ?></td><td><?= h($row['entidade_id']) ?></td></tr><?php endforeach; ?><?php if(!$ultimosLogs): ?><tr><td colspan="5" class="text-secondary">Nenhum log encontrado.</td></tr><?php endif; ?></tbody></table></div></div>
<?php layout_footer(); ?>
