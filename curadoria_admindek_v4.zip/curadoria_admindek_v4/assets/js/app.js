(function(){
const flash=window.__FLASH__;
if(flash){openAlert(flash.type||'info',flash.title||'',flash.message||'');}
document.addEventListener('click',function(e){
  const btn=e.target.closest('[data-confirm]');
  if(!btn) return;
  e.preventDefault();
  const msg=btn.getAttribute('data-confirm')||'Confirma esta ação?';
  const form=btn.closest('form');
  openConfirm('warning','Confirmar ação',msg,function(){ if(form) form.submit(); });
});
function openAlert(type,title,message){
  const root=document.getElementById('customModalRoot');
  const icon=({success:'✅',danger:'❌',warning:'⚠️',info:'ℹ️'})[type]||'ℹ️';
  root.innerHTML=`<div class="flash-backdrop"><div class="flash-modal"><div class="flash-head"><div class="d-flex align-items-center gap-2"><div style="font-size:1.3rem">${icon}</div><div><div class="fw-bold">${esc(title||def(type))}</div><div class="text-secondary small">${esc((type||'info').toUpperCase())}</div></div></div><button class="btn btn-sm btn-light border" data-close>Fechar</button></div><div class="flash-body text-secondary" style="white-space:pre-wrap">${esc(message)}</div><div class="flash-foot"><button class="btn app-btn-primary text-white px-4" data-close>OK</button></div></div></div>`;
  bind(root);
}
function openConfirm(type,title,message,onConfirm){
  const root=document.getElementById('customModalRoot');
  const icon=({success:'✅',danger:'❌',warning:'⚠️',info:'ℹ️'})[type]||'ℹ️';
  root.innerHTML=`<div class="flash-backdrop"><div class="flash-modal"><div class="flash-head"><div class="d-flex align-items-center gap-2"><div style="font-size:1.3rem">${icon}</div><div><div class="fw-bold">${esc(title||def(type))}</div><div class="text-secondary small">${esc((type||'info').toUpperCase())}</div></div></div><button class="btn btn-sm btn-light border" data-close>Cancelar</button></div><div class="flash-body text-secondary" style="white-space:pre-wrap">${esc(message)}</div><div class="flash-foot"><button class="btn btn-light border px-4" data-close>Cancelar</button><button class="btn app-btn-primary text-white px-4" id="confirmProceed">Continuar</button></div></div></div>`;
  bind(root); const p=document.getElementById('confirmProceed'); if(p) p.addEventListener('click',function(){ root.innerHTML=''; onConfirm(); });
}
function bind(root){ root.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>root.innerHTML='')); const bd=root.querySelector('.flash-backdrop'); if(bd) bd.addEventListener('click',e=>{ if(e.target===bd) root.innerHTML=''; });}
function def(type){ return ({success:'Sucesso',danger:'Erro',warning:'Atenção',info:'Informação'})[type]||'Informação';}
function esc(str){ return String(str).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
window.appUI={openAlert,openConfirm};
})();