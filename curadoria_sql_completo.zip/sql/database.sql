
IF DB_ID('CURADORIA') IS NULL
BEGIN
    CREATE DATABASE CURADORIA;
END
GO

USE CURADORIA;
GO

CREATE TABLE colaboradores(
 id INT IDENTITY PRIMARY KEY,
 matricula VARCHAR(30),
 nome VARCHAR(200),
 perfil VARCHAR(50),
 senha VARCHAR(100),
 ativo BIT
);

CREATE TABLE temas(
 id INT IDENTITY PRIMARY KEY,
 nome VARCHAR(150),
 ativo BIT
);

CREATE TABLE tipos_conteudo(
 id INT IDENTITY PRIMARY KEY,
 nome VARCHAR(150),
 ativo BIT
);

CREATE TABLE conteudos(
 id INT IDENTITY PRIMARY KEY,
 titulo VARCHAR(500),
 descricao NVARCHAR(MAX),
 link_url VARCHAR(500),
 tema_id INT,
 tipo_id INT,
 carga_horaria TIME,
 versao INT,
 ativo BIT
);

CREATE TABLE trilhas(
 id INT IDENTITY PRIMARY KEY,
 nome VARCHAR(300),
 tema_id INT
);

CREATE TABLE trilha_conteudos(
 id INT IDENTITY PRIMARY KEY,
 trilha_id INT,
 conteudo_id INT,
 ordem INT
);

CREATE TABLE logs_auditoria(
 id INT IDENTITY PRIMARY KEY,
 usuario_id INT,
 acao VARCHAR(100),
 entidade VARCHAR(100),
 entidade_id INT,
 criado_em DATETIME DEFAULT GETDATE()
);

INSERT INTO colaboradores VALUES
('1001','Admin Exemplo','Admin','admin123',1),
('1002','Curador Exemplo','Curador','curador123',1),
('1003','Leitor Exemplo','Leitor','leitor123',1);

INSERT INTO temas VALUES
('Suporte Técnico',1),
('Comercial',1),
('Financeiro',1),
('RH',1);

INSERT INTO tipos_conteudo VALUES
('Video',1),
('PPT',1),
('PDF',1),
('Gamificação',1);

INSERT INTO conteudos VALUES
('Diagnóstico de modem','Procedimento técnico','https://intranet/modem',1,1,'00:25:00',1,1),
('Atendimento inicial','Fluxo atendimento','https://intranet/atendimento',1,2,'00:15:00',1,1),
('Onboarding técnico','Treinamento novos','https://intranet/onboard',1,1,'00:45:00',1,1);

INSERT INTO trilhas VALUES
('Trilha suporte técnico',1);

INSERT INTO trilha_conteudos VALUES
(1,3,1),
(1,1,2),
(1,2,3);
